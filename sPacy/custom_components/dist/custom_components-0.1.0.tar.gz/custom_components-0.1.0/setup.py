from setuptools import setup, find_packages
def readme():
    with open('README.rst') as f:
        return f.read()
setup(name='custom_components',
      version='0.1.0',
      description='Generate custom_ner_components',
      long_description='Generation, build and save custom ner components.',
      classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: MIT License',
        'Programming Language :: Python :: 3.11',
        'Topic :: OOP Python :: Code',
      ],
      url='http://github.com/sednabcn/sPacy',
      entry_points = {
        'console_scripts': ['custom_components-sample_1=custom_components.script_custom_patterns:pattern_gen','custom_components-sample_2=custom_components.script_custom_ner:get_ner_component'],
      },
      author="Ruperto Pedro Bonet Chaple",
      author_email="ruperto.bonet@modelphysmat.com",
      license="MIT",
      packages=find_packages(['custom_components','custom_components.custom_ner','custom_components.patterns','custom_components.tests','custom_components.models','custom_components.mappings','custom_components.scripts','custom_components.normalize'], exclude=['custom_components.__pycache__']),
      package_data={'custom_components':['datasets/*','data_spacy/*']},
      #packages=['custom_components','custom_components.custom_ner','custom_components.patterns','custom_components.tests','custom_components.models','custom_components.mappings','custom_components.scripts','custom_components.normalize'],
      install_requires=[
          'numpy','sPacy','pandas','nltk'],
      test_suite='nose.collector',
      tests_require=['nose'],
      scripts=['./custom_components/scripts/script_custom_entities.py','./custom_components/scripts/script_custom_ner.py','./custom_components/scripts/script_custom_patterns.py','./custom_components/scripts/script_normalize_datasets.py'],
      include_package_data=True,
      zip_safe=False)

