#/usr/bin/python3
from importlib import resources
from custom_componnets.utils import upload_spacy_training_data,upload_spacy_training_data_from_json

def load(filename,style=None):
        import os
        import pandas as pd
        """
        Load files like as datasets, ner, entities,models
        style:
        1) datasets
        2) ner
        3) entities
        4) models
        """
        #path_file=os.abspath(filename)
        ext=filename.split(".")[-1]
        if ext=='csv':
            # Load CSV file into a dataframe
            with resources.open_text('custom_components.datasets', filename) as file:
                df = pd.read_csv(file)
            return df
            
        elif ext=='xls' or ext=='xlsx':
            # Load Excel file into a dataframe
            with resources.open_binary('custom_components.datasets', filename) as file:
                df = pd.read_excel(file)
            return df
        
        elif ext=='txt':
            # Access a resource within the 'data' subpackage of 'my_package'
            with resources.open_text('custom_components.datasets', filename) as file:
                data = file.read()
            return data
            
        elif style=="ner":
            import spacy
            from custom_components.tests import custom_desc_components, custom_formulas_components
            # Load SpaCy model file
            with resources.path('custom_components.data_spacy',filename +'/') as model_path:
                nlp = spacy.load(model_path)
            return nlp
        
        elif ext=='spacy' and style=="entity":            
            ner_entity="ner_"+filename.split('_')[1]
            with resources.path('custom_components.data_spacy','/') as model_path:
                data_=upload_spacy_training_data(model_path,filename,ner_entity)
            return data_

        elif ext=="json" and style=="entity":
            with resources.path('custom_components.data_spacy','/') as model_path:
                 data_=upload_spacy_training_data_from_json(model_path,filename)
            return data_
        elif style=="models":
            import spacy
            from custom_components.tests import custom_desc_components, custom_formulas_components
            # Load SpaCy model file
            with resources.path('custom_components.data_spacy',filename +'/') as model_path:
                nlp = spacy.load(model_path)
            return nlp
        


        else:
            pass
