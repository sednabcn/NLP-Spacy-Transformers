

class Training:
    def __init__(self,train_data,path_ner_model, niter, drop, batchsize,option=None):
        
        self.path_ner_model=path_ner_model
        self.niter=niter
        self.drop=drop
        self.batchsize=batchsize

        if isinstance(training_data,type)=='list':
           self.training_data_1=training_data[0]
           self.training_data_2=training_data[1]
        else:
           self.training_data=training_data
        self.option=option #number of batches
        
    def training_data(self):
        import spacy
        import random
        from spacy.util import minibatch, compounding
        from spacy.training import Example
        import pandas as pd

        # Step 1: Load Your Customized Model
        nlp = spacy.load(self.path_ner_model)  # Load your custom model
        
        # Assume 'ner' is in your custom model pipeline
        ner = nlp.get_pipe('ner')

        # Add new entity labels to the NER
        for _, annotations in self.training_data:
            for ent in annotations.get('entities'):
                ner.add_label(ent[2])

        # Prepare the examples
        examples = [Example.from_dict(nlp.make_doc(text), annotations) for text, annotations in self.training_data]

        # Optionally disable other pipeline components during training
        other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'ner']

        history = pd.DataFrame(columns=['niter', 'losses'])

        with nlp.disable_pipes(*other_pipes):  # only train NER
            optimizer = nlp.resume_training()
            for i in range(self.niter):
                losses = {}
                random.shuffle(examples)
                batches = minibatch(examples, size=self.batchsize)
                for batch in batches:
                    
                    nlp.update(
                        batch,
                        drop=self.drop,
                        losses=losses,
                        sgd=optimizer
                    )
                print("Losses", losses)
                history.loc[i] = [i, losses['ner']]

        return history

    def training_data_multitask(self):
        import spacy
        import random
        from spacy.util import minibatch, compounding
        from spacy.training import Example
        import pandas as pd
        from itertools import cycle

        nlp = spacy.load(self.path_ner_model)  # Load your custom model

        # Prepare the examples for both NER datasets
        examples_ner1 = [Example.from_dict(nlp.make_doc(text), annotations) for text, annotations in self.training_data_1]
        examples_ner2 = [Example.from_dict(nlp.make_doc(text), annotations) for text, annotations in self.training_data_2]


        # Optionally disable other pipeline components during training
        other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'ner']

        history = pd.DataFrame(columns=['niter', 'losses_ner'])

        with nlp.disable_pipes(*other_pipes):  # only train NER
            optimizer = nlp.resume_training()
            for i in range(self.niter):
                losses = {}
                # Shuffle and create batches for both NER datasets
                random.shuffle(examples_ner1)
                random.shuffle(examples_ner2)

                if option=="2":
                
                    batches_ner1 = minibatch(examples_ner1, size=self.batchsize)
                    batches_ner2 = minibatch(examples_ner2, size=self.batchsize)

                    # Alternate between updating with NER1 and NER2 batches
                    for batch_ner1, batch_ner2 in zip(batches_ner1, batches_ner2):

                        nlp.update(
                            batch_ner1,
                            drop=self.drop,
                            losses=losses,
                            sgd=optimizer
                        )
                        nlp.update(
                            batch_ner2,
                            drop=self.drop,
                            losses=losses,
                            sgd=optimizer
                        )

                elif option=="1":
                   
                    # Interleave examples from both datasets to mix training data across iterations
                    examples_mixed = list(zip(examples_ner1, examples_ner2))
                    random.shuffle(examples_mixed)
                    examples_mixed = [ex for pair in examples_mixed for ex in pair]  # Flatten list

                    batches = minibatch(examples_mixed, size=self.batchsize)

                    # Update model for each batch
                    for batch in batches:
                        nlp.update(
                            batch,
                            drop=self.drop,
                            losses=losses,
                            sgd=optimizer
                        )
                else:
                    pass
                
                print(f"Iteration {i}, Losses", losses)
                history.loc[i] = [i, losses.get('ner', 0)]

        return history

