
class mapping_desc_to_formulas:

       def __init__(self,  ):




       def map_vocab_to_vocab():
           
import re  # Regular expressions for pattern matching

def extract_column_name(description):
    # A simple regex pattern to find "of [Column Name]"
    # This pattern might need to be adjusted based on actual descriptions
    match = re.search(r"of (\w+ \w+)", description)
    if match:
        return match.group(1)  # Return the column name
    return None

def generate_tableau_formula(description):
    vocab_map = {
        "total": "SUM",
        "average": "AVG",
        "median": "MEDIAN",
        "number of entries": "COUNT",
        "unique count": "COUNT DISTINCT"
    }

    column_name = extract_column_name(description)
    if column_name is None:
        return "Column name not found"

    for key, value in vocab_map.items():
        if key in description.lower():
            return f"{value}({column_name})"

    return "Formula not found"

# Example usage
description = "Average of Petal Length across all flowers"
print(generate_tableau_formula(description))


           
       def map_sentence_to_sentence(description):
           # Normalize the description
           normalized_description = description.lower()

           # Mapping rules
           mapping_rules = {
               "sum of sales by year": "SUM(Sales) GROUP BY Year",
               "average cost per item": "AVG(Cost) / COUNT(Item)",
           }

           # Apply rules
           for pattern, formula in mapping_rules.items():
               if pattern in normalized_description:
                   return formula

               # Fallback if no rule matched
               return "Formula not recognized. Please provide more details."

           # Example usage
description = "Sum of sales by year"
print(map_description_to_formula(description))

######
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# Load the dataset
data = pd.read_csv('Descriptions-Formulas.csv')

# Preprocess the data
X = data['Description']
y = data['Formula (Tableau)']

# Convert the text descriptions to numerical features
vectorizer = CountVectorizer()
X_vectorized = vectorizer.fit_transform(X)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y, test_size=0.2, random_state=42)

# Train the logistic regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Evaluate the model on the test set
accuracy = model.score(X_test, y_test)
print(f'Accuracy: {accuracy:.2f}')

# Make predictions on new data
new_descriptions = [
    "Sum of Sepal Length",
    "Average Sepal Width across all entries",
    "Find the median Petal Length",
    "Count the number of records in the dataset"
]
new_X_vectorized = vectorizer.transform(new_descriptions)
new_formulas = model.predict(new_X_vectorized)

for desc, formula in zip(new_descriptions, new_formulas):
    print(f"Description: {desc}, Formula: {formula}")

####
# Load the pre-trained transformer model
nlp = load_model("en_core_web_trf")

# Load the dataset
data = pd.read_csv('Descriptions-Formulas.csv')

# Preprocess the data
X = data['Description']
y = data['Formula (Tableau)']

# Process the text data using the spaCy transformer model
docs = [nlp(text) for text in X]

# Extract the text and labels
X_vectorized = np.stack([doc.vector for doc in docs])
y_vectorized = np.stack([nlp(formula).vector for formula in y])

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y_vectorized, test_size=0.2, random_state=42)

# Train a logistic regression model
clf = LogisticRegression()
clf.fit(X_train, y_train)

# Evaluate the model
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.2f}")

# Make predictions on new data
new_descriptions = [
    "Sum of Sepal Length",
    "Average Sepal Width across all entries",
    "Find the median Petal Length",
    "Count the number of records in the dataset"
]
new_docs = [nlp(text) for text in new_descriptions]
new_X_vectorized = np.stack([doc.vector for doc in new_docs])
new_formulas = clf.predict(new_X_vectorized)

for desc, formula in zip(new_descriptions, new_formulas):
    print(f"Description: {desc}, Formula: {formula}")
